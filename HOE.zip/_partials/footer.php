<footer class="footer footerCustomClass" id="footerCustomClass">
    ©<?php echo date("Y"); ?> <span class="d-none d-sm-inline-block"> - Crafted with <i class="mdi mdi-heart text-danger"></i> by Team Pixelium.</span>
</footer>

